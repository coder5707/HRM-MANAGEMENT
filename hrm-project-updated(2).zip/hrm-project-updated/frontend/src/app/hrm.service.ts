import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Employee {
  id?: string;
  name: string;
  department: string;
  designation: string;
  dateOfJoining: string;
  status: string;
}

export interface LeaveRequest {
  id?: number;
  employeeName: string;
  leaveType: string;
  fromDate: string;
  toDate: string;
  reason: string;
  status?: string;
}

export interface DashboardStats {
  totalEmployees: number;
  activeEmployees: number;
  pendingLeaveRequests: number;
  departments: number;
}

@Injectable({ providedIn: 'root' })
export class HrmService {
  private base = 'http://localhost:3000/api';

  constructor(private http: HttpClient) {}

  getDashboard(): Observable<DashboardStats> {
    return this.http.get<DashboardStats>(`${this.base}/dashboard`);
  }

  getEmployees(): Observable<Employee[]> {
    return this.http.get<Employee[]>(`${this.base}/employees`);
  }

  addEmployee(emp: Employee): Observable<{ message: string; employee: Employee }> {
    return this.http.post<{ message: string; employee: Employee }>(`${this.base}/employees`, emp);
  }

  getLeaveRequests(): Observable<LeaveRequest[]> {
    return this.http.get<LeaveRequest[]>(`${this.base}/leave-requests`);
  }

  submitLeaveRequest(leave: LeaveRequest): Observable<{ message: string; leave: LeaveRequest }> {
    return this.http.post<{ message: string; leave: LeaveRequest }>(`${this.base}/leave-requests`, leave);
  }
}
