import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { HrmService, DashboardStats } from '../hrm.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, MatCardModule],
  template: `
    <div class="page">
      <div class="page-header">
        <div>
          <h1 class="page-title">Dashboard</h1>
          <p class="page-sub">Welcome back, Admin · {{ today }}</p>
        </div>
      </div>

      <div class="stats-grid" *ngIf="stats">
        <div class="stat-card" *ngFor="let card of cards" [style.--accent]="card.color">
          <div class="stat-icon" [style.background]="card.color + '18'">
            <span class="material-icons" [style.color]="card.color">{{ card.icon }}</span>
          </div>
          <div class="stat-body">
            <span class="stat-value">{{ getStatValue(card.key) }}</span>
            <span class="stat-label">{{ card.label }}</span>
          </div>
          <div class="stat-bg-icon">
            <span class="material-icons">{{ card.icon }}</span>
          </div>
        </div>
      </div>

      <div class="info-section">
        <div class="info-card">
          <h3 class="info-title">
            <span class="material-icons">info</span>
            About This System
          </h3>
          <p>This is a beginner HRM web application built with <strong>Angular</strong> + <strong>TypeScript</strong> frontend and <strong>Node.js</strong> + <strong>TypeScript</strong> backend. All data is sample/dummy data stored in memory.</p>
        </div>
        <div class="dept-card">
          <h3 class="info-title">
            <span class="material-icons">business</span>
            Departments
          </h3>
          <div class="dept-list">
            <span class="dept-chip" *ngFor="let d of departments">{{ d }}</span>
          </div>
        </div>
      </div>
    </div>
  `,
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  stats: DashboardStats | null = null;
  today = new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  departments = ['Engineering', 'HR', 'Finance', 'Marketing'];

  cards = [
    { key: 'totalEmployees',      label: 'Total Employees',       icon: 'people',       color: '#6366f1' },
    { key: 'activeEmployees',     label: 'Active Employees',      icon: 'how_to_reg',   color: '#10b981' },
    { key: 'pendingLeaveRequests',label: 'Pending Leave Requests',icon: 'pending_actions', color: '#f59e0b' },
    { key: 'departments',         label: 'Departments',           icon: 'business',     color: '#3b82f6' },
  ];

  constructor(private hrm: HrmService) {}

  ngOnInit(): void {
    this.hrm.getDashboard().subscribe(data => this.stats = data);
  }

  getStatValue(key: string): number {
    return this.stats ? (this.stats as unknown as Record<string,number>)[key] : 0;
  }
}
