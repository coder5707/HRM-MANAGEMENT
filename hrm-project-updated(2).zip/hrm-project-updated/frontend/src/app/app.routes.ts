import { Routes } from '@angular/router';
import { DashboardComponent }    from './dashboard/dashboard.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { AddEmployeeComponent }  from './add-employee/add-employee.component';
import { LeaveRequestComponent } from './leave-request/leave-request.component';

export const routes: Routes = [
  { path: '',              redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard',    component: DashboardComponent },
  { path: 'employees',    component: EmployeeListComponent },
  { path: 'add-employee', component: AddEmployeeComponent },
  { path: 'leave',        component: LeaveRequestComponent },
];
