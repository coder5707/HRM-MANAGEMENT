import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { HrmService, LeaveRequest } from '../hrm.service';

@Component({
  selector: 'app-leave-request',
  standalone: true,
  imports: [
    CommonModule, FormsModule,
    MatFormFieldModule, MatInputModule, MatSelectModule,
    MatButtonModule, MatTableModule,
  ],
  template: `
    <div class="page">
      <div class="page-header">
        <div>
          <h1 class="page-title">Leave Request</h1>
          <p class="page-sub">Submit a new leave request and view existing ones</p>
        </div>
      </div>

      <!-- Form -->
      <div class="form-card">
        <div class="card-header">
          <span class="material-icons">edit_calendar</span>
          <span>Submit Leave Request</span>
        </div>

        <div class="success-banner" *ngIf="successMsg">
          <span class="material-icons">check_circle</span>
          {{ successMsg }}
        </div>

        <form (ngSubmit)="submit()" #lf="ngForm" class="form-body">
          <div class="form-row">
            <label class="field-label">Employee Name <span class="req">*</span></label>
            <mat-form-field appearance="outline" class="full-width">
              <input matInput [(ngModel)]="leave.employeeName" name="employeeName" placeholder="Your name" required />
            </mat-form-field>
          </div>

          <div class="form-row">
            <label class="field-label">Leave Type <span class="req">*</span></label>
            <mat-form-field appearance="outline" class="full-width">
              <mat-select [(ngModel)]="leave.leaveType" name="leaveType" required>
                <mat-option *ngFor="let t of leaveTypes" [value]="t">{{ t }}</mat-option>
              </mat-select>
            </mat-form-field>
          </div>

          <div class="date-row">
            <div class="form-row">
              <label class="field-label">From Date <span class="req">*</span></label>
              <mat-form-field appearance="outline" class="full-width">
                <input matInput type="date" [(ngModel)]="leave.fromDate" name="fromDate" required />
              </mat-form-field>
            </div>
            <div class="form-row">
              <label class="field-label">To Date <span class="req">*</span></label>
              <mat-form-field appearance="outline" class="full-width">
                <input matInput type="date" [(ngModel)]="leave.toDate" name="toDate" required />
              </mat-form-field>
            </div>
          </div>

          <div class="form-row">
            <label class="field-label">Reason <span class="req">*</span></label>
            <mat-form-field appearance="outline" class="full-width">
              <textarea matInput [(ngModel)]="leave.reason" name="reason" rows="3" placeholder="Brief reason for leave..." required></textarea>
            </mat-form-field>
          </div>

          <div class="form-actions">
            <button mat-raised-button color="primary" type="submit" [disabled]="lf.invalid">
              <span class="material-icons">send</span>
              Submit Request
            </button>
          </div>
        </form>
      </div>

      <!-- Table -->
      <div class="table-card">
        <div class="card-header">
          <span class="material-icons">list_alt</span>
          <span>Leave Requests — {{ leaveRequests.length }} records</span>
        </div>
        <div class="table-wrap">
          <table mat-table [dataSource]="leaveRequests" class="hrm-table">
            <ng-container matColumnDef="employeeName">
              <th mat-header-cell *matHeaderCellDef>Employee Name</th>
              <td mat-cell *matCellDef="let r">
                <div class="emp-name">
                  <div class="av">{{ r.employeeName.charAt(0) }}</div>
                  {{ r.employeeName }}
                </div>
              </td>
            </ng-container>

            <ng-container matColumnDef="leaveType">
              <th mat-header-cell *matHeaderCellDef>Leave Type</th>
              <td mat-cell *matCellDef="let r">
                <span class="leave-type-tag">{{ r.leaveType }}</span>
              </td>
            </ng-container>

            <ng-container matColumnDef="dateRange">
              <th mat-header-cell *matHeaderCellDef>Date Range</th>
              <td mat-cell *matCellDef="let r" class="date-range">
                <span class="material-icons">date_range</span>
                {{ r.fromDate }} → {{ r.toDate }}
              </td>
            </ng-container>

            <ng-container matColumnDef="status">
              <th mat-header-cell *matHeaderCellDef>Status</th>
              <td mat-cell *matCellDef="let r">
                <span class="status-pending">
                  <span class="dot"></span>Pending
                </span>
              </td>
            </ng-container>

            <tr mat-header-row *matHeaderRowDef="cols"></tr>
            <tr mat-row *matRowDef="let row; columns: cols;" class="trow"></tr>
          </table>
        </div>
      </div>
    </div>
  `,
  styleUrls: ['./leave-request.component.css']
})
export class LeaveRequestComponent implements OnInit {
  leave: LeaveRequest = { employeeName: '', leaveType: '', fromDate: '', toDate: '', reason: '' };
  leaveRequests: LeaveRequest[] = [];
  successMsg = '';
  cols = ['employeeName', 'leaveType', 'dateRange', 'status'];
  leaveTypes = ['Casual Leave', 'Sick Leave', 'Annual Leave', 'Maternity Leave', 'Emergency Leave'];

  constructor(private hrm: HrmService) {}

  ngOnInit(): void {
    this.hrm.getLeaveRequests().subscribe(d => this.leaveRequests = d);
  }

  submit(): void {
    this.hrm.submitLeaveRequest(this.leave).subscribe({
      next: (res) => {
        this.successMsg = `✓ ${res.message}`;
        this.leaveRequests = [...this.leaveRequests, res.leave];
        this.leave = { employeeName: '', leaveType: '', fromDate: '', toDate: '', reason: '' };
        setTimeout(() => this.successMsg = '', 4000);
      },
    });
  }
}
