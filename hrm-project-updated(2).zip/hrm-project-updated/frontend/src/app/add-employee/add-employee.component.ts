import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { HrmService, Employee } from '../hrm.service';

@Component({
  selector: 'app-add-employee',
  standalone: true,
  imports: [
    CommonModule, FormsModule,
    MatFormFieldModule, MatInputModule, MatSelectModule,
    MatButtonModule, MatSnackBarModule,
  ],
  template: `
    <div class="page">
      <div class="page-header">
        <div>
          <h1 class="page-title">Add Employee</h1>
          <p class="page-sub">Fill in the details to add a new employee to the system</p>
        </div>
      </div>

      <div class="form-card">
        <div class="form-header">
          <span class="material-icons">person_add</span>
          <span>New Employee Details</span>
        </div>

        <div class="success-banner" *ngIf="successMsg">
          <span class="material-icons">check_circle</span>
          {{ successMsg }}
        </div>

        <form (ngSubmit)="save()" #f="ngForm" class="form-body">
          <div class="form-row">
            <label class="field-label">Employee Name <span class="required">*</span></label>
            <mat-form-field appearance="outline" class="full-width">
              <input matInput [(ngModel)]="emp.name" name="name" placeholder="e.g. Arun Kumar" required />
            </mat-form-field>
          </div>

          <div class="form-row">
            <label class="field-label">Department <span class="required">*</span></label>
            <mat-form-field appearance="outline" class="full-width">
              <mat-select [(ngModel)]="emp.department" name="department" required>
                <mat-option *ngFor="let d of departments" [value]="d">{{ d }}</mat-option>
              </mat-select>
            </mat-form-field>
          </div>

          <div class="form-row">
            <label class="field-label">Designation <span class="required">*</span></label>
            <mat-form-field appearance="outline" class="full-width">
              <input matInput [(ngModel)]="emp.designation" name="designation" placeholder="e.g. Senior Developer" required />
            </mat-form-field>
          </div>

          <div class="form-row">
            <label class="field-label">Date of Joining <span class="required">*</span></label>
            <mat-form-field appearance="outline" class="full-width">
              <input matInput type="date" [(ngModel)]="emp.dateOfJoining" name="dateOfJoining" required />
            </mat-form-field>
          </div>

          <div class="form-row">
            <label class="field-label">Status <span class="required">*</span></label>
            <mat-form-field appearance="outline" class="full-width">
              <mat-select [(ngModel)]="emp.status" name="status" required>
                <mat-option value="Active">Active</mat-option>
                <mat-option value="Inactive">Inactive</mat-option>
              </mat-select>
            </mat-form-field>
          </div>

          <div class="form-actions">
            <button mat-raised-button color="primary" type="submit" [disabled]="f.invalid" class="save-btn">
              <span class="material-icons">save</span>
              Save Employee
            </button>
            <button mat-button type="button" (click)="reset(f)" class="reset-btn">
              <span class="material-icons">refresh</span>
              Reset
            </button>
          </div>
        </form>
      </div>
    </div>
  `,
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent {
  emp: Employee = { name: '', department: '', designation: '', dateOfJoining: '', status: '' };
  successMsg = '';
  departments = ['Engineering', 'HR', 'Finance', 'Marketing'];

  constructor(private hrm: HrmService, private snack: MatSnackBar) {}

  save(): void {
    this.hrm.addEmployee(this.emp).subscribe({
      next: (res) => {
        this.successMsg = `✓ ${res.message} — ${res.employee.id}`;
        this.emp = { name: '', department: '', designation: '', dateOfJoining: '', status: '' };
        setTimeout(() => this.successMsg = '', 5000);
      },
      error: () => this.snack.open('Failed to save employee', 'Close', { duration: 3000 }),
    });
  }

  reset(f: any): void {
    f.resetForm();
    this.emp = { name: '', department: '', designation: '', dateOfJoining: '', status: '' };
    this.successMsg = '';
  }
}
