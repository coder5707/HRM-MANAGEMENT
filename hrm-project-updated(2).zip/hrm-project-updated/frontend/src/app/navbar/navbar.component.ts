import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive, CommonModule],
  template: `
    <nav class="sidebar">
      <div class="brand">
        <div class="brand-icon">
          <span class="material-icons">corporate_fare</span>
        </div>
        <div class="brand-text">
          <span class="brand-name">HRM</span>
          <span class="brand-sub">Management</span>
        </div>
      </div>

      <ul class="nav-links">
        <li *ngFor="let item of navItems">
          <a [routerLink]="item.path" routerLinkActive="active" class="nav-item">
            <span class="material-icons nav-icon">{{ item.icon }}</span>
            <span class="nav-label">{{ item.label }}</span>
          </a>
        </li>
      </ul>

      <div class="sidebar-footer">
        <div class="user-card">
          <div class="user-avatar">A</div>
          <div class="user-info">
            <span class="user-name">Admin</span>
            <span class="user-role">HR Manager</span>
          </div>
        </div>
      </div>
    </nav>
  `,
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  navItems = [
    { path: '/dashboard',    icon: 'dashboard',   label: 'Dashboard' },
    { path: '/employees',    icon: 'people',      label: 'Employees' },
    { path: '/add-employee', icon: 'person_add',  label: 'Add Employee' },
    { path: '/leave',        icon: 'event_note',  label: 'Leave Request' },
  ];
}
