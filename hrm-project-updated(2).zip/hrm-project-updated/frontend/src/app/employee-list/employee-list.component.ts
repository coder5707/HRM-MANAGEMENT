import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatChipsModule } from '@angular/material/chips';
import { HrmService, Employee } from '../hrm.service';

@Component({
  selector: 'app-employee-list',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatChipsModule],
  template: `
    <div class="page">
      <div class="page-header">
        <div>
          <h1 class="page-title">Employees</h1>
          <p class="page-sub">{{ employees.length }} total employees on record</p>
        </div>
      </div>

      <div class="table-card">
        <div class="table-toolbar">
          <span class="material-icons toolbar-icon">people</span>
          <span class="toolbar-title">Employee Directory</span>
        </div>
        <div class="table-wrap">
          <table mat-table [dataSource]="employees" class="hrm-table">
            <ng-container matColumnDef="id">
              <th mat-header-cell *matHeaderCellDef>Emp. ID</th>
              <td mat-cell *matCellDef="let e">
                <span class="id-badge">{{ e.id }}</span>
              </td>
            </ng-container>

            <ng-container matColumnDef="name">
              <th mat-header-cell *matHeaderCellDef>Employee Name</th>
              <td mat-cell *matCellDef="let e">
                <div class="emp-name-cell">
                  <div class="avatar">{{ e.name.charAt(0) }}</div>
                  <span>{{ e.name }}</span>
                </div>
              </td>
            </ng-container>

            <ng-container matColumnDef="department">
              <th mat-header-cell *matHeaderCellDef>Department</th>
              <td mat-cell *matCellDef="let e">
                <span class="dept-tag" [class]="getDeptClass(e.department)">{{ e.department }}</span>
              </td>
            </ng-container>

            <ng-container matColumnDef="designation">
              <th mat-header-cell *matHeaderCellDef>Designation</th>
              <td mat-cell *matCellDef="let e">{{ e.designation }}</td>
            </ng-container>

            <ng-container matColumnDef="status">
              <th mat-header-cell *matHeaderCellDef>Status</th>
              <td mat-cell *matCellDef="let e">
                <span class="status-badge" [class.active]="e.status === 'Active'" [class.inactive]="e.status !== 'Active'">
                  <span class="status-dot"></span>{{ e.status }}
                </span>
              </td>
            </ng-container>

            <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
            <tr mat-row *matRowDef="let row; columns: displayedColumns;" class="table-row"></tr>
          </table>
        </div>
      </div>
    </div>
  `,
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  employees: Employee[] = [];
  displayedColumns = ['id', 'name', 'department', 'designation', 'status'];

  constructor(private hrm: HrmService) {}

  ngOnInit(): void {
    this.hrm.getEmployees().subscribe(data => this.employees = data);
  }

  getDeptClass(dept: string): string {
    const map: Record<string, string> = {
      'Engineering': 'dept-tag dept-eng',
      'HR':          'dept-tag dept-hr',
      'Finance':     'dept-tag dept-fin',
      'Marketing':   'dept-tag dept-mkt',
    };
    return map[dept] || 'dept-tag dept-def';
  }
}
