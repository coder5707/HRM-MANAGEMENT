import * as http from 'http';
import * as url from 'url';

// ─── Sample Data ────────────────────────────────────────────────────────────
const employees = [
  { id: 'EMP001', name: 'Arun Kumar',    department: 'Engineering',  designation: 'Senior Developer', status: 'Active',   dateOfJoining: '2021-03-15' },
  { id: 'EMP002', name: 'Priya Sharma',  department: 'HR',           designation: 'HR Manager',       status: 'Active',   dateOfJoining: '2020-07-01' },
  { id: 'EMP003', name: 'Rahul Nair',    department: 'Finance',      designation: 'Finance Analyst',  status: 'Inactive', dateOfJoining: '2019-11-20' },
  { id: 'EMP004', name: 'Deepa Rajan',   department: 'Marketing',    designation: 'Marketing Lead',   status: 'Active',   dateOfJoining: '2022-01-10' },
  { id: 'EMP005', name: 'Vikram Mehta',  department: 'Engineering',  designation: 'Backend Engineer', status: 'Active',   dateOfJoining: '2021-09-05' },
  { id: 'EMP006', name: 'Sneha Pillai',  department: 'HR',           designation: 'HR Executive',     status: 'Active',   dateOfJoining: '2023-02-14' },
  { id: 'EMP007', name: 'Karthik Raja',  department: 'Finance',      designation: 'Accountant',       status: 'Active',   dateOfJoining: '2020-05-30' },
  { id: 'EMP008', name: 'Anitha Suresh', department: 'Marketing',    designation: 'Content Writer',   status: 'Active',   dateOfJoining: '2022-08-22' },
  { id: 'EMP009', name: 'Suresh Babu',   department: 'Engineering',  designation: 'QA Engineer',      status: 'Active',   dateOfJoining: '2021-12-01' },
  { id: 'EMP010', name: 'Meena Lakshmi', department: 'Engineering',  designation: 'UI Developer',     status: 'Inactive', dateOfJoining: '2020-03-18' },
];

const leaveRequests = [
  { id: 1, employeeName: 'Arun Kumar',   leaveType: 'Casual Leave',  fromDate: '2025-01-10', toDate: '2025-01-12', reason: 'Personal work',    status: 'Pending' },
  { id: 2, employeeName: 'Priya Sharma', leaveType: 'Sick Leave',    fromDate: '2025-01-15', toDate: '2025-01-16', reason: 'Not feeling well', status: 'Pending' },
  { id: 3, employeeName: 'Deepa Rajan',  leaveType: 'Annual Leave',  fromDate: '2025-01-20', toDate: '2025-01-25', reason: 'Vacation',         status: 'Pending' },
];

const dashboard = {
  totalEmployees: 25,
  activeEmployees: 20,
  pendingLeaveRequests: 3,
  departments: 4,
};

// ─── CORS + JSON Helpers ─────────────────────────────────────────────────────
function sendJSON(res: http.ServerResponse, data: unknown, status = 200): void {
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  });
  res.end(JSON.stringify(data));
}

function readBody(req: http.IncomingMessage): Promise<string> {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', (chunk) => (body += chunk));
    req.on('end', () => resolve(body));
  });
}

// ─── Server ──────────────────────────────────────────────────────────────────
const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url || '/', true);
  const path   = parsed.pathname || '/';
  const method = req.method || 'GET';

  if (method === 'OPTIONS') { sendJSON(res, {}); return; }

  if (method === 'GET' && path === '/api/dashboard')        { sendJSON(res, dashboard);      return; }
  if (method === 'GET' && path === '/api/employees')        { sendJSON(res, employees);      return; }
  if (method === 'GET' && path === '/api/leave-requests')   { sendJSON(res, leaveRequests);  return; }

  if (method === 'POST' && path === '/api/employees') {
    const body = await readBody(req);
    const emp  = JSON.parse(body);
    const newEmp = { id: `EMP${String(employees.length + 1).padStart(3, '0')}`, ...emp };
    employees.push(newEmp);
    sendJSON(res, { message: 'Employee added successfully', employee: newEmp }, 201);
    return;
  }

  if (method === 'POST' && path === '/api/leave-requests') {
    const body    = await readBody(req);
    const leave   = JSON.parse(body);
    const newLeave = { id: leaveRequests.length + 1, status: 'Pending', ...leave };
    leaveRequests.push(newLeave);
    sendJSON(res, { message: 'Leave request submitted successfully', leave: newLeave }, 201);
    return;
  }

  sendJSON(res, { error: 'Not found' }, 404);
});

const PORT = 3000;
server.listen(PORT, () => console.log(`✅  HRM Backend running at http://localhost:${PORT}`));
